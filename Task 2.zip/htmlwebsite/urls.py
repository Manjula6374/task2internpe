from django.contrib import admin
from django.urls import include, path
from htmlwesite import views

urlpatterns = [
    path('', Home.as_view(), name='home'),
]